CREATE TABLE IF NOT EXISTS `#__adminpraise_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `link` text,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL,
  `access` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `home` int(1) NOT NULL,
  `checked_out` int(11) unsigned NOT NULL,
  `browserNav` tinyint(4) NOT NULL,
  `note` varchar(255) NOT NULL,
  `sublevel` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `menutype` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `componentid` (`published`,`access`)
);

CREATE TABLE IF NOT EXISTS `#__adminpraise_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
);
