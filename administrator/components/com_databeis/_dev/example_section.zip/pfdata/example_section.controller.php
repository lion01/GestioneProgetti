<?php
/*
* This file contains the controller class. Its methods are normally called 
* from the *.init.php file. The controller class is responsible for preparing
* data and assembling pages.
*/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );

// The class extends "PFobject" which is located in: com_projectfork/_core/core.php
class PFexampleController extends PFobject
{
    /**
     * Constructor. Nothing special about it
     **/
    public function __construct()
    {
        // Call PFobject constructor
        parent::__construct();
        
        // You can write any custom code below here
    }
    
    /**
     * Displays a list of example items that the user has created
     *      
     **/
	public function DisplayList()
	{
	    // Get PF user class instance - Needed for the profile settings
        $user = PFuser::GetInstance();
        // Create new instance of the section class (see: example_section.class.php)
        $class = new PFexampleClass();
        // Create a new instance of the form helper class (see: com_projectfork/_core/lib/utilities.php)
        $form = new PFform();
        
        // Get current workspace from user profile
        $project = $user->GetWorkspace();
        
        // Get user list limit/limitstart
        $limit      = (int) JRequest::getVar('limit', $user->GetProfile('examplelist_limit', 50));
		$limitstart = (int) JRequest::getVar('limitstart', 0);
		
        /**
        * PREPARE DATA TABLE
        **/
        // Order data by field?
        $ob  = JRequest::getVar('ob', $user->GetProfile("examplelist_ob", 'e.title'));
        // Order direction?
		$od  = JRequest::getVar('od', $user->GetProfile("examplelist_od", 'ASC'));
		// Table header titles
		$ts1 = array('TITLE', 'AUTHOR', 'ID');
		// Table header fields
		$ts2 = array('e.title', 'u.name', 'e.id');
		// Possible order directions
		$ts3 = array('ASC', 'DESC');
		
		// Sanitize user input
		if(!in_array($ob, $ts2)) $ob = 'e.title';
		if(!in_array($od, $ts3)) $od = 'ASC';
		
		// Create new data table instance (See com_projectfork/_core/lib/utilities.php)
		$table = new PFtable($ts1, $ts2, $ob, $od);
		
		// Load items from the database
		$total = $class->Count($project);
		$rows  = $class->LoadList($limitstart, $limit, $ob, $od, $project);
		
		// Set form fields to auto-complete
		$form->SetBind(true, 'REQUEST');
		
		// Setup standard Joomla pagination
		$pagination = new JPagination($total, $limitstart, $limit);
		
		// Save user profile settings
		$user->SetProfile("examplelist_ob", $ob);
		$user->SetProfile("examplelist_od", $od);
		$user->SetProfile("examplelist_limit", $limit);
		
		// Include the output file - The method "GetOutput" is part of the PFobject class!
		require_once( $this->GetOutput('list_items.php') );
    }
    
    /**
     * Displays a form for creating a new item
     *      
     **/
    public function DisplayNew()
    {
        // Create a new instance of the form helper class (see: com_projectfork/_core/lib/utilities.php)
        $form = new PFform();
        
        // Set form fields to auto-complete
		$form->SetBind(true, 'REQUEST');
		
        // Include the output file - The method "GetOutput" is part of the PFobject class!
		require_once( $this->GetOutput('form_new.php') );
    }
    
    /**
     * Displays a form for editing an item
     * 
     * @param   integer   The record id to edit          
     **/
    public function DisplayEdit($id)
    {
        // Create a new instance of the form helper class (see: com_projectfork/_core/lib/utilities.php)
        $form = new PFform();
        // Create new instance of the section class (see: example_section.class.php)
        $class = new PFexampleClass();
        
        // Load the item from the database
        $row = $class->Load($id);
        
        // Check if an item was found and redirect back to list if nothing was found
        if(!is_object($row)) {
            $this->SetRedirect("section=example_section", 'MSG_EXAMPLE_E_EDIT');
            return false;
        }
        
        // Set form fields to auto-complete
		$form->SetBind(true, $row);
        
        // Include the output file - The method "GetOutput" is part of the PFobject class!
		require_once( $this->GetOutput('form_edit.php') );
    }
    
    /**
     * Stores an item and then redirects back to the list overview
     * 
     * @return    boolean    True on success, False on error          
     **/
    public function Save()
    {
        // Create new instance of the section class (see: example_section.class.php)
        $class = new PFexampleClass();
        
        // Attempt to save item and redirect with error on failure
        if(!$class->Save()) {
            $this->SetRedirect("section=example_section", 'MSG_EXAMPLE_E_SAVE');
            return false;
        }
        
        // Everything went good. Redirect to list with success message
        $this->SetRedirect("section=example_section", 'MSG_EXAMPLE_S_SAVE');
        return true;
    }
    
    /**
     * Updates an item and then redirects back to the list overview
     * 
     * @param     integer    The record id to update     
     * @return    boolean    True on success, False on error            
     **/
    public function Update($id)
    {
        // Create new instance of the section class (see: example_section.class.php)
        $class = new PFexampleClass();
        
        // Attempt to update item and redirect with error on failure
        if(!$class->Update($id)) {
            $this->SetRedirect("section=example_section", 'MSG_EXAMPLE_E_UPDATE');
            return false;
        }
        
        // Everything went good. Redirect to list with success message
        $this->SetRedirect("section=example_section", 'MSG_EXAMPLE_S_UPDATE');
        return true;
    }
}
?>