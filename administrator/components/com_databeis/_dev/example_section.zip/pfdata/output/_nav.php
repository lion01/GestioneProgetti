<?php
/**
* This file generates the section navigation.
* It is automatically included by the panel "nav_section_subnav"
**/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load core object
$core = PFcore::GetInstance();

// Create new form
$form = new PFform('adminForm_subnav');

// Start output
$html = '';

// Decide which navigation to display based on the current task
switch( $core->GetTask() )
{
    // Default view
	default:
		$html .= '
		<div class="pf_navigation">
            <ul>
                <li class="btn pf_new">'.$form->NavButton('NEW', 'section=example_section&task=form_new', 'TT_NEW_ITEM', 'form_new').'</li>
            </ul>
        </div>';
		break;

    // New item form
	case 'form_new':
        $html .= '
		<div class="pf_navigation">
           <ul>
              <li class="btn pf_save">'.$form->NavButton('SAVE', "javascript:submitbutton('task_save')", 'TT_CREATE_ITEM', 'task_save').'</li>
              <li class="btn pf_cancel">'.$form->NavButton('CANCEL', "section=example_section", 'TT_BACK').'</li>
           </ul>
        </div>';
		break;
		
	// Edit item form
	case 'form_edit':
	    $html .= '
        <div class="pf_navigation">
            <ul>
                <li class="btn pf_save">'.$form->NavButton('SAVE', "javascript:submitbutton('task_update')", 'TT_UPDATE', 'task_update').'</li>
                <li class="btn pf_cancel">'.$form->NavButton('CANCEL', "section=example_section", 'TT_BACK').'</li>
            </ul>
        </div>';
		break;
}

// Display output
echo $html;
unset($core,$form,$html);
?>