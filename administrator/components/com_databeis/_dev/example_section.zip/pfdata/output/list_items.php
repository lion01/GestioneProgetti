<?php
/**
* This file generates the HTML output of the record list
**/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );

// Start form output
echo $form->Start();
?>
<a id="pf_top"></a>
<div class="pf_container">
    <div class="pf_header componentheading">
        
        <!-- 
        Generate breadcrumbs and Section edit-button. Class PFformat can be found in:
        com_projectfork/_core/lib/utilities.php
        -->
        <h3><?php echo PFformat::WorkspaceTitle()." / ".PFformat::Lang('EXAMPLE_SECTION');?>
        <?php echo PFformat::SectionEditButton();?>
        </h3>
        
    </div>
    <div class="pf_body">
        
        <!-- Table start -->
        <table class="pf_table adminlist" width="100%" cellpadding="0" cellspacing="0">
            <thead>
                <tr>
                   <th align="center" class="sectiontableheader title">#</th>
                   <th align="left" class="sectiontableheader title pf_title_header"><?php echo $table->TH(0); // TITLE ?></th>
                   <th align="left" class="sectiontableheader title pf_title_header"></th>
                   <th align="center" class="sectiontableheader title"><?php echo $table->TH(1); // AUTHOR ?></th>
                   <th align="left" class="sectiontableheader title"><?php echo $table->TH(2); // ID ?></th>
                </tr>
            </thead>
            <tbody id="table_body">
            
            <?php
            $html = "";
            $k    = 0;
            
            // Loop through records
            foreach ($rows AS $i => $row)
            {
                // Sanitize each record for output
                JFilterOutput::objectHTMLSafe($row);
                
                // Setup edit link
                $link_edit = PFformat::Link("section=example_section&task=form_edit&id=$row->id");
                // Setup author profile link
                $link_profile = PFformat::Link("section=profile&task=display_details&id=$row->author");
                
                // Check view profile permission
                $can_profile = $user->Access('display_details', 'profile', $row->author);
                
                // Generate author avatar
                $avatar = PFavatar::Display($row->author, false);
                
                // Wrap avatar into profile link if the user is allowed to view it
                if($can_profile) $avatar = '<a href="'.$link_profile.'">'.$avatar.'</a>';
                
                // Start generating row output
                $html .= '
                <tr class="row'.$k.' sectiontableentry'.($k + 1).'">
                    <td>'.$pagination->getRowOffset( $i ).'</td>
                    <td class="item_title"><div class="pf_title_wrap"><strong>'.$row->title.'</strong></div></td>
                    <td class="pf_actions_cell">';
                    
                    // Start action menu for item
                    $html .= $table->Menu();
                    // Generate button: link, title, css-class, permission-task, permission-section
                    $html .= $table->MenuItem($link_edit,'TT_EDIT','pf_edit', 'form_edit');
                    // Close the menu
                    $html .= $table->Menu(false);
                    
                    $html .= '
                    </td>
                    <td class="pf_author_cell">'.$avatar.'</td>
                    <td><span>'.$row->id.'</span></td>
                </tr>';
                
                $k = 1 - $k;
            }
            
            // Display html
            echo $html;
            
            // Give out message if no records have been found
            if(!count($rows)) {
                echo '
                <tr class="row0 sectiontableentry1">
      	            <td colspan="5" align="center" style="text-align:center"><div class="pf_info">'.PFformat::Lang('NO_ITEMS').'</div></td>
      	        </tr>';
            }
            
            unset($rows, $html);
            ?>
            
            <!-- Table list footer -->
            <tr>
                <td colspan="5" style="text-align:center"><?php echo $pagination->getListFooter(); ?></td>
            </tr>
            
            </tbody>
        </table>
        <!-- Table end -->
        
    </div>
</div>
<?php
// Add hidden form fields
echo $form->HiddenField("option");
echo $form->HiddenField("section");
echo $form->HiddenField("task");
echo $form->HiddenField("ob", $ob);
echo $form->HiddenField("od", $od);

// Close form
echo $form->End();
?>