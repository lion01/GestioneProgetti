<?php
/*
* This file should contain the html and php code for you theme.
* It is automatically included by the Projectfork framework.
* From here you can also load your css/js files.
* 
* The file "index_ajax.php" is used for dynamic calls and lightbox windows.
*/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );


/*
* This is how you can load a CSS file from your theme's "css" folder.
**/ 
$load = PFload::GetInstance();
$load->ThemeCSS('theme.css');


/*
* This is how you can load a process event inside your theme.
* It will fire all processes that are tied to the event you specify
*/
PFprocess::Event('theme_header');


/*
* This is how you can load a specific panel inside your theme.
* Note that the first argument must be the "name" of the panel, not the "title".
* See the db table "jos_pf_panels".
*/
echo PFpanel::Render("theme_logo");
// Same as before, but with a different style. Styles must be in the "html_core" folder of your theme!
echo PFpanel::Render("theme_logo", "panel_simple");


/*
* This is how you load a panel position.
* Basically it displays all panels that are assigned to the specified position
* rather than loading them manually.
*/
PFpanel::Position("theme_header");
// Same as before, but with a different style. Styles must be in the "html_core" folder of your theme!
PFpanel::Position("theme_header", "panel_simple");


/*
* This is how you render the current section content.
* Does not have any arguments.
*/
PFsection::Render();


/*
* This is how you can retrieve config settings for your theme.
* The first argument must be the name of the config setting (see your theme xml file)
* The second parameter must be the name of your theme
*/
$cfg = PFconfig::GetInstance();
$setting = $cfg->Get('my_setting', 'example_theme');


/*
* You can also retrieve system settings, such as "hide joomla template"
*/
$hide = $cfg->Get('hide_template', 'system');

?>