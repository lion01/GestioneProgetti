<?php
/*
* This file should contain the html and php code for you theme.
* It is automatically included by the Projectfork framework.
* From here you can also load your css/js files.
* 
* This file is used for dynamic calls and lightbox windows.
* For code examples, see "index.php"
*/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );
?>